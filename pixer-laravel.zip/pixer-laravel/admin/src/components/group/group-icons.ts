export const typeIconList = [
  {
    value: 'FixedIcon',
    label: 'Fixed',
  },
  {
    value: 'LiquidIcon',
    label: 'Liquid',
  },
  {
    value: 'ResponsiveIcon',
    label: 'Responsive',
  },
  {
    value: 'NoTypeIcon',
    label: 'N/A',
  },
];
